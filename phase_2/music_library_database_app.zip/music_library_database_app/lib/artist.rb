class Artist
  attr_accessor :id, :name, :genre
end