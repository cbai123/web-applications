class Album
  attr_accessor :id, :title, :release_year, :artist_id
end